package ch.unige.cui.rpg;

public class MageRobes implements Protection {

    //cette classe est a completer pour Ex1 ... 

    public int getWeight() {
        return 0;
    }

    public MageRobes(int unknownArg1, int unknownArg2){
        //A completer ...
    }

    public Damage absorb(Damage dmg) {
        return new Damage();
    }

    public Damage getMageRobesProt() {
        return new Damage();
    }

}
