package ch.unige.cui.rpg;

public interface Protection extends Equipment {
    public Damage absorb(Damage dmg);
}