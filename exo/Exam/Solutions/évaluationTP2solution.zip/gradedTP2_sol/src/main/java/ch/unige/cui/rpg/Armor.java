package ch.unige.cui.rpg;

public class Armor{
    private final int MAX_ARMOR_VAL = 100;
    private int armorVal;
    private DmgType armorType;

    public Armor(int armorVal, DmgType armorType){
        if(armorVal<=MAX_ARMOR_VAL){
            this.armorVal=armorVal;
            this.armorType = armorType;
        }
        else{// < Exo? > on peut enlever le else et demander aux etudiants de creer un exception pour ce cas comme exo simple
            //unchecked -> RunTimeException -> does not need to be in try catch statement
            throw new IllegalArgumentException("Illegal armorVal. Max possible armor value: " + MAX_ARMOR_VAL + ".");
        }
    }

    public int getArmorVal(){
        return armorVal;
    }

    public DmgType getArmorType(){
        return armorType;
    }

    //< Exo? > on pourrait aussi comme exercice simple demander de mettre en place l absorbtion des degats
    //considerant la valeur d armure comme un pourcentage et de prendre garde au casting double <-> int
    public Damage absorb(Damage dmg){
        switch (armorType) {
            case PHYSICAL:
                return new Damage( ((int) Math.round( dmg.getPhysical()*(1.0-(armorVal/100.0)))), dmg.getMagical() );
            case MAGICAL:
                return new Damage(dmg.getPhysical(),  ((int) Math.round( dmg.getMagical()*(1.0-(armorVal/100.0)))));
            default:
                return new Damage(0,0);
        }
    }
}