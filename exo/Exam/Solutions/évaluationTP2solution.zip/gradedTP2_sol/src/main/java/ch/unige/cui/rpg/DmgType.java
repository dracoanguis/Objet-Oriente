package ch.unige.cui.rpg;

public enum DmgType{
    PHYSICAL, MAGICAL
}