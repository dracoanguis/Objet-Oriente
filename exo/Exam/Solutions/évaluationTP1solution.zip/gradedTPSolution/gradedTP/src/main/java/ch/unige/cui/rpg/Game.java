package ch.unige.cui.rpg;

public class Game{
	public static void main(String[] args){
		System.out.println("Successfully entered in main.");
	}
}