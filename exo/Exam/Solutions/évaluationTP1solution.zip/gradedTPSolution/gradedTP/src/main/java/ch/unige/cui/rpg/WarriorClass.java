package ch.unige.cui.rpg;

public class WarriorClass extends GameCharacter implements CharClass {

    public WarriorClass(String name,
                int maxHP, 
                int gold, 
                ProtectionStack protectionSt,
                CharProfile pr
                ){
                super(name,maxHP,gold,protectionSt,pr);
    }

    public CharProfile levelUp(CharProfile pr){
        int newXPVal = 0;
        int newLvl = pr.getLvl()+1;
        
        int strengthVal=1;
        int stamVal=2;
        
        return new CharProfile(pr.getIntellect(), pr.getStrength()+strengthVal, pr.getStamina()+stamVal, newXPVal, newLvl);
    }


    @Override
    public int completeQuest(Quest q) {
        int questXp = super.completeQuest(q);
        CharProfile currentPr = super.getPr();
        
        if( (currentPr.getXp()+questXp) >= LevelClass.getXPToNextLvl(currentPr.getLvl()) ){
            CharProfile newPr = levelUp(currentPr);
            super.setPr(newPr);
        } 
        else {
            CharProfile newPr = new CharProfile(currentPr.getIntellect(), 
                                        currentPr.getStrength(), 
                                        currentPr.getStamina(), 
                                        currentPr.getXp()+questXp, 
                                        currentPr.getLvl());
            super.setPr(newPr);
        }
        return questXp;
    }


}
