package ch.unige.cui.rpg;

public interface Equipment{
    public int getWeight();
}