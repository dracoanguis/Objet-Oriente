package ch.unige.cui.rpg;

public class MageClass extends GameCharacter implements CharClass{
    
    public MageClass(String name,
                int maxHP,
                int gold,
                ProtectionStack protectionSt,
                CharProfile pr
                ) {
        super(name,maxHP,gold,protectionSt,pr);
    }
    
    public CharProfile levelUp(CharProfile pr){
        int newLvl = pr.getLvl()+1;
        int newXPVal = 0;
        int intellectVal = 3;
        int stamVal = 0;
        
        if( (newLvl % 2) == 0 ){
            stamVal = 1;
        }
        
        return new CharProfile(pr.getIntellect()+intellectVal, pr.getStrength(), pr.getStamina()+stamVal, newXPVal, newLvl);
    }

    @Override
    public int completeQuest(Quest q) {
        int questXp = super.completeQuest(q);
        CharProfile currentPr = super.getPr();
        
        if( (currentPr.getXp()+questXp) >= LevelClass.getXPToNextLvl(currentPr.getLvl()) ){
            CharProfile newPr = levelUp(currentPr);
            super.setPr(newPr);
        } 
        else {
            CharProfile newPr = new CharProfile(currentPr.getIntellect(), 
                                        currentPr.getStrength(), 
                                        currentPr.getStamina(), 
                                        currentPr.getXp()+questXp, 
                                        currentPr.getLvl());
            super.setPr(newPr);
        }
        return questXp;
    }
  
}