package ch.unige.cui.rpg;

public class MageRobes implements Protection {
    private final Damage mageRobesProt;
    private final int weight;

    
    public int getWeight() {
        return weight;
    }

    public MageRobes(int magicalProtVal, int weight){
        //protects agains magical dmg only
        mageRobesProt = new Damage(0,magicalProtVal,0,0);
        this.weight=weight;
    }

    
    public Damage absorb(Damage dmg) {
        //only absorbs magical damage
        return new Damage(dmg.getPhysical(), 
                        dmg.getMagical()-mageRobesProt.getMagical(),
                        dmg.getElectrical(),
                        dmg.getFire());
    }

    public Damage getMageRobesProt() {
        return mageRobesProt;
    }

}
