package ch.unige.cui.rpg;
import java.util.ArrayList;
import ch.unige.cui.rpg.DmgType;

public class Game{
	public static void main(String[] args){
		System.out.println("Successfully entered in main.");
		
	}
}