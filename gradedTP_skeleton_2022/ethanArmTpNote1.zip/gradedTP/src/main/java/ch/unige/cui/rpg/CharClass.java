package ch.unige.cui.rpg;

import ch.unige.cui.rpg.CharProfile;

public interface CharClass {
    public CharProfile levelUp(CharProfile pr);
}