package ch.unige.cui.rpg;

public enum PlayerClass {
    WARRIOR, MAGE
}
