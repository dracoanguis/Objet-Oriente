package ch.unige.cui.rpg;

public interface ArenaItem {
    public int getWeight();
}
