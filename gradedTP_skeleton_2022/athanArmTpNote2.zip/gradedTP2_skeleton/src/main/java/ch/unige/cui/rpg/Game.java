package ch.unige.cui.rpg;
import java.util.ArrayList;
import ch.unige.cui.rpg.DmgType;

public class Game{
	public static void main(String[] args){
		/*
		Player p3 = new Player("Sauron",200,  new Armor(99, DmgType.PHYSICAL), new CharProfile(105,25,10),PlayerClass.MAGE);
		Player p1 = new Player("Smeagol",50,  new Armor(99, DmgType.PHYSICAL), new CharProfile(1,5,5),PlayerClass.WARRIOR);
		Player p2 = new Player("Gandalf",100, new Armor(55,DmgType.MAGICAL), new CharProfile(10, 2, 3), PlayerClass.MAGE);


		MagicalObject magicalSword = new MagicalObject(33,10,0,21);
		
		ArrayList<Item> arenaInventory = new ArrayList<>();
		arenaInventory.add(magicalSword);

		System.out.println("START OF SCENARIO: v2");
		System.out.println(p1.toString());
		System.out.println(p1.getPr().getIntellect());
		System.out.println();
		System.out.println("arenaInventory:"+arenaInventory.toString());
		System.out.println();
		System.out.println();
		System.out.println();

		boolean b = magicalSword.equip(p1, arenaInventory);

		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println("After EQUIP:" + b);
		System.out.println();
		System.out.println(p1.toString());
		System.out.println();
		System.out.println();
		System.out.println("arenaInventory:"+arenaInventory.toString());


		b = magicalSword.unEquip(p1, arenaInventory);

		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println("After UNEQUIP:" + b);
		System.out.println();
		System.out.println(p1.toString());
		System.out.println();
		System.out.println();
		System.out.println("arenaInventory:"+arenaInventory.toString());


		 b = magicalSword.equip(p1, arenaInventory);

		 System.out.println();
		 System.out.println();
		 System.out.println();
		 System.out.println();
		 System.out.println("After EQUIP:" + b);
		 System.out.println();
		 System.out.println(p1.toString());
		 System.out.println();
		 System.out.println();
		 System.out.println("arenaInventory:"+arenaInventory.toString());



		 
		b = magicalSword.unEquip(p1, arenaInventory);
		
		b = magicalSword.unEquip(p1, arenaInventory);
		
		b = magicalSword.unEquip(p1, arenaInventory);

		
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println("After UNEQUIP:" + b);
		System.out.println();
		System.out.println(p1.toString());
		System.out.println();
		System.out.println();
		System.out.println("arenaInventory:"+arenaInventory.toString());
		

		b = magicalSword.equip(p1, arenaInventory);
		b = magicalSword.equip(p1, arenaInventory);
		b = magicalSword.equip(p1, arenaInventory);


		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println("After EQUIP:" + b);
		System.out.println();
		System.out.println(p1.toString());
		System.out.println();
		System.out.println();
		System.out.println("arenaInventory:"+arenaInventory.toString());



		System.out.println("p2.getCurrentHP():"+p2.getCurrentHP());
		
		System.out.println("p3.getPr().getIntellect():"+p3.getPr().getIntellect());
		p3.attack(p2);

		System.out.println("p2.getCurrentHP():"+p2.getCurrentHP());
		System.out.println("p1.getCurrentHP():"+p1.getCurrentHP());

		*/
		
	}
}