package rpg;
import java.util.*;
import java.io.*; 
import java.util.stream.*;

public class Main {

    public static void main(String[] args){
		//String fn = "./src/main/resources/potions.txt";
		//ArrayList<String> tmp = Game.readFile("iii");
	
		System.out.println("Successfully entered in main.");
    	Stream<Item> test = Game.createManaPotionStream();
    }

}
