package rpg;

public interface Item{
    public int getPrice();
}
